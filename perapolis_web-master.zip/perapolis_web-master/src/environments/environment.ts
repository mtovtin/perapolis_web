// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {

  apiKey: "AIzaSyBjf7Uqcnx5JQsWaNhj1G4BKgpjT_LjIP4",
  authDomain: "perapolis-7a24c.firebaseapp.com",
  projectId: "perapolis-7a24c",
  storageBucket: "perapolis-7a24c.appspot.com",
  messagingSenderId: "414740028554",
  appId: "1:414740028554:web:e51e741b2f88293003e173",
  measurementId: "G-RS3JWWRPXM"

  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
